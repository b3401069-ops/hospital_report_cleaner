"""Hospital report cleaning package."""
